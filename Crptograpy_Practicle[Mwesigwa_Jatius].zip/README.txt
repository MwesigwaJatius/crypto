MWESIGWA JATIUS 
2023/U/MMU/BCS/00107

Documentation for Question 1:  RSA Encryption and Decryption in Python 
This code implements RSA encryption and decryption using the PyCryptodome library. It 
includes functions to generate RSA key pairs, encrypt a message with the public key, and 
decrypt the cipher text using the private key 
Key Functions 
1. Key Generation (generate_rsa_keys):Generates a 2048-bit RSA key pair (private and 
public) and exports them for later use. 
2. Message Encryption (encrypt_message):Takes a public key and a plaintext message (e.g., 
"Hello, World!"), encrypts it using the PKCS1_OAEP cipher, and returns the cipher text in base64 
format. 
3. Message Decryption (decrypt_message):Accepts the private key and the base64-encoded 
cipher text, decrypts it, and returns the original message as a string. 
Usage Example 
The provided example shows how to generate keys, encrypt a message, and decrypt the resulting 
cipher text, printing both the cipher text and the decrypted message to confirm the processes 
work correctly. 
Libraries Used 
PyCryptodome: Key library for RSA functions, including: 
Crypto.PublicKey.RSA:  for key generation. 
Crypto.Cipher.PKCS1_OAEP: for secure encryption/decryption. 
base64: for encoding ciphertext. 

Documentation for Question two: Diffie-Hellman Key Exchange in Python 
This code implements the Diffie-Hellman key exchange algorithm, allowing two parties (Alice 
and Bob) to securely generate a shared secret key and use it for encrypting and decrypting 
messages. 
Overview of Functions 
1. Prime and Generator Generation (generate_prime_and_generator): 
This function returns a small prime number (23) and a primitive root (7) as the generator. These 
values facilitate the key exchange process. 
2. Key Exchange (dh_key_exchange): 
This function simulates the Diffie-Hellman process: 
Alice generates a private key and computes her public key using the formula 
generatorprivatemod?(prime) 
Bob similarly generates a private key and computes his public key. 
Both parties calculate a shared secret using each other's public keys and their own private keys. 
The function returns both shared secrets (which should match) and the public keys of both 
parties. 
3. Encryption and Decryption (encrypt_decrypt): 
This function performs a simple XOR operation for encryption and decryption. It takes a 
message and a key, returning the transformed message. 
Usage Example
*	Generate Prime and Generator:The code begins by generating a prime number and its 
generator.
*	Perform Key Exchange:Alice and Bob exchange public keys and derive their shared secrets.
*	Print Results:The public keys and shared secrets are printed to verify the exchange.
*	Message Encryption and Decryption: 
Alice encrypts a message ("hello bob") using her shared secret, and Bob decrypts the message 
using his shared secret. The encrypted message and the decrypted message are printed to 
confirm the process. 
Key Points 
The implementation ensures that both Alice and Bob derive the same shared secret, crucial 
for secure communication.The XOR method used for encryption is basic and primarily for 
demonstration purposes; in real applications, more secure encryption methods should be used. 
This code effectively demonstrates the core principles of the Diffie-Hellman key exchange, 
showcasing how two parties can securely share a secret key for further encrypted 
communication.

Documentation for question 3,  SHA-256 Hash Functions in Python 
This code implements SHA-256 hashing using the hashlib library in Python. It provides 
functions to compute the hash of a message and verify the integrity of that message using its 
hash.
Key Functions
1.	Compute SHA-256 Hash (compute_sha256):This function takes a string message as 
input and computes its SHA-256 hash.The message is encoded to bytes, and the hash is 
generated using hashlib.sha256(). The result is returned as a hexadecimal string 
representation of the hash.
2.	Verify Integrity (verify_integrity):This function checks if the original message's 
integrity is intact by comparing the computed hash of the original message with a 
provided hash value.It calls the compute_sha256 function and returns True if the hashes 
match, indicating the message has not been altered.
Usage Example 
Message Definition: A message ("Good morning!") is defined. 
Hash Computation: The SHA-256 hash of the message is computed and stored. 
Integrity Verification: The integrity of the original message is verified against the computed 
hash, returning a boolean value.
Print Results: The computed hash and the integrity verification result are printed to confirm the 
process. 
This implementation effectively demonstrates how to compute and verify SHA-256 hashes, 
ensuring message integrity in a straightforward manner.

Documentation for Question 4: ECDSA Digital Signatures in Python 
This code implements the Elliptic Curve Digital Signature Algorithm (ECDSA), allowing for the 
generation of key pairs, signing messages, and verifying signatures.
Key Functions 
Generate ECDSA Key Pair (generate_ecdsa_key_pair): 
This function generates a key pair using the P-256 elliptic curve. It returns both the private key 
and the corresponding public key. 
Sign Message (sign_message): This function signs a message using the ECDSA private key. It 
first creates a SHA-256 hash of the message, then uses the private key to generate a digital 
signature, which is returned. 
Verify Signature (verify_signature):This function verifies the signature of a message using 
the ECDSA public key. It hashes the message, then checks if the provided signature is valid. It 
returns True if valid and False otherwise.
Usage Example
1.	Generate Key Pair: The code begins by generating an ECDSA key pair.
2.	Sign Message: The message "Hello, World!" is signed using the private key, producing a 
digital signature.
3.	Verify Signature: The signature is then verified using the public key, and the validity of 
the signature is printed.

Conclusion
This series of implementations covers key cryptographic techniques in Python, 
including RSA encryption and decryption, Diffie-Hellman key exchange, SHA-256 
hashing, and ECDSA digital signatures. Each implementation demonstrates 
generating key pairs, encrypting or signing messages, and verifying integrity or 
authenticity. These fundamental algorithms illustrate secure communication 
methods and data integrity in modern cryptography. Together, they provide a 
comprehensive overview of essential cryptographic operations.
